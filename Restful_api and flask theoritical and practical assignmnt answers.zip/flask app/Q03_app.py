#How do you define different routes with different HTTP methods in Flask4
from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/form', methods=['GET', 'POST'])
def handle_form():
    if request.method == 'POST':
        name = request.form['username']
        return render_template('form.html', name=name)
    else:
        return render_template('form.html', name=None)

if __name__ == '__main__':
    app.run(debug=True)
