#9 How do you redirect to a different route in Flask?
from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'supersecret123'  # Required for session management


@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')

        if username:
            session['username'] = username
            return redirect(url_for('profile'))  # Redirects to profile page
        else:
            return render_template('user_login_form.html', error="Please enter your name.")

    return render_template('user_login_form.html')  # Uses renamed HTML


@app.route('/profile')
def profile():
    if 'username' in session:
        return f"<h1>Welcome, {session['username']}!</h1><br><a href='/logout'>Logout</a>"
    else:
        return redirect(url_for('login'))


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)
