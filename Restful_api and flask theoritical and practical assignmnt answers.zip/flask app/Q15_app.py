#15. How do you capture URL parameters in Flask?
from flask import Flask, redirect, url_for, request, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return '''
        <form action="/redirect_me">
            <input type="text" name="username" placeholder="Enter your name" required>
            <input type="number" name="age" placeholder="Enter your age" required>
            <button type="submit">Go</button>
        </form>
    '''

@app.route('/redirect_me')
def redirect_me():
    name = request.args.get('username')  # Get from form input
    age = request.args.get('age')        # Get from form input

    return redirect(url_for('greet', name=name, age=age))

@app.route('/greet')
def greet():
    name = request.args.get('name')
    age = request.args.get('age')
    return f"<h1>Hello {name}!</h1><p>You are {age} years old.</p>"


if __name__ == '__main__':
    app.run(debug=True)
