#14. How do you return JSON responses in Flask?
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/api/data')
def get_data():
    data = {
        "name": "Reshma",
        "age": 25,
        "role": "Data Analyst"
    }
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)
