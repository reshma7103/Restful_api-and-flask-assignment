# 12.How do you define a custom Jinja filter in Flask?
from flask import Flask, render_template

app = Flask(__name__)

# Custom Jinja filter to reverse a string
@app.template_filter('reverse')
def reverse_string(s):
    return s[::-1]

# Route using the custom filter
@app.route('/')
def home():
    return render_template('custom_filter.html', message="Hello Flask")

if __name__ == '__main__':
    app.run(debug=True)
