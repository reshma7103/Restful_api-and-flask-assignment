#13. How can you redirect with query parameters in Flask?
from flask import Flask, redirect, url_for, request, render_template_string

app = Flask(__name__)

@app.route('/')
def home():
    # Redirect to /greet with query parameters
    return redirect(url_for('greet', name='Reshma', age=25))

@app.route('/greet')
def greet():
    name = request.args.get('name')
    age = request.args.get('age')
    return render_template_string(
        "<h1>Hello {{ name }}! You are {{ age }} years old.</h1>",
        name=name, age=age
    )

if __name__ == '__main__':
    app.run(debug=True)
