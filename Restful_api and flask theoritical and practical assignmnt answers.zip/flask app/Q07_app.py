#7. How can you validate form data in Flask?

from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    error = None
    if request.method == 'POST':
        name = request.form['username']
        if not name.strip():
            error = "Name is required!"
        else:
            return f"Hello, {name}!"
    return render_template('user_form.html', error=error)
if __name__ == '__main__':
    app.run(debug=True)
