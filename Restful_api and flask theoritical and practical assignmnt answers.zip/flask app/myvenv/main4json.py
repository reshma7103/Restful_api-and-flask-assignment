#import flask

from flask import Flask,jsonify,render_template

#create flask instance
app = Flask(__name__)
##deefine  function and route
#'/' '/about ,'/data'
@app.route('/')
#def home():
   ### return "welcome to my website"
 #@app.route('/about')
 #def about():
   # data= "this is my websited created in 2025"
   # return data
 #@app.route('/data')
 ##def data():
    #user_data = {"name":"Reshma","Age":23}
    #return jsonify(user_data)
@app.route('/')
def home_page():
    name ='Reshma'
    return render_template('index.html',name=name)
##trigger the flask app
if __name__ == '__main__':
  app.run(debug = True)