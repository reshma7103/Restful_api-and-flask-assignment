from flask import Flask,jsonify
API_KEY = "b9a6154903c9466e985e18538aa198c2"
url= "https://newsapi.org/v2/everything?q=apple&from=2025-07-23&to=2025-07-23&sortBy=popularity&apiKey=b9a6154903c9466e985e18538aa198c2
app =Flask(__name__)

#define function here
@app.route('/api/news',methods=['GET'])
def get_news():
if response.status_code ==200:
    response = requests.get(url)
    news_data=eponse.json()
    total_articles =len(news_data['articles'])
    first_article=news_data['articles'][0]
    author = first_article['author']
    title=first_article['title']
    publishedAt=first_article['publishedAt']
    output_data = {"Total Article Count":total_articles,
               "Title":title,
               "Author":author,
               "published Date":publishedAt}
    return jsonify(output_data)
else:
    return jsonify("msg":"invalid api key")
    
  

if __name__=='main':
    app.run(debug=True)