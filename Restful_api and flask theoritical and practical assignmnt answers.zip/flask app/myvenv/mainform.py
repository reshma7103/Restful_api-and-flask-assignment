#import flask

from flask import Flask,render_template

#create flask instance
app = Flask(__name__)
##deefine  function and route
@app.route('/',methods=['GET'])
def form(methods=['GET']):
    render_template("form.html")
@app.route('/form',methods=['GET'])
def welcome():
    return "we have received info"

##trigger the flask app
if __name__ == '__main__':
    app.run()