from flask import Flask
from auth.routes import auth_bp  # Import the blueprint

app = Flask(__name__)
app.register_blueprint(auth_bp)  # Register the blueprint

if __name__ == '__main__':
    app.run(debug=True)
