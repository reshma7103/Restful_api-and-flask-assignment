from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])  # Handle both GET and POST
def index():
    if request.method == 'POST':
        username = request.form['username']
        return f"Hello, {username}!"  # Response after form submission
    return render_template('user_form.html')  # Show form for GET

if __name__ == '__main__':
    app.run(debug=True)
