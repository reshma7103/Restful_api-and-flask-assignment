from flask import Blueprint, render_template, request

# Define blueprint
auth_bp = Blueprint('auth', __name__, template_folder='templates')

# Route for login page
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        return f"Welcome, {username}!"  # Respond with greeting
    return render_template('access_portal.html')  # Render form on GET
