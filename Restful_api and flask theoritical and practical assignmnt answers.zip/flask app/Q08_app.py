from flask import Flask, session, redirect, url_for, request, render_template

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for session to work securely

@app.route('/')
def home():
    if 'username' in session:
        return f"Logged in as {session['username']}"
    return "You are not logged in"

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        session['username'] = request.form['username']
        return redirect(url_for('home'))
    return '''
        <form method="post">
            <input type="text" name="username" placeholder="Enter username">
            <input type="submit" value="Login">
        </form>
    '''

@app.route('/logout')
def logout():
    session.pop('username', None)  # Removes the user from session
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
